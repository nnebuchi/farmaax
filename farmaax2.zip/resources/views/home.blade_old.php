@extends('layouts.auth')
@section('title')
@section('content')
    <h1>Development in progress</h1>
@endsection
