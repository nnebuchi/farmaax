    
    <?php $__env->startSection('title', 'Upload a farm on Farmaax'); ?>
    <?php $__env->startSection('content'); ?>
        <style>
            input {
                border: 2px solid #676501 !important;
            }

            label {
                color: #4e9525 !important;
            }

            .card {
                border: 2px solid #676501 !important;
                border-radius: 12px;
                ">

            }

            .card-header {
                border-radius: 12px;
                background-color: #4e9525 !important;
                border-bottom: 2px solid #676501;
                color: white;
                font-weight: bold;
            }

            .card-header h4 {
                color: white;
                font-weight: bold;
            }

        </style>
        <div class="container mt-4">
            <div class="row justify-content-center">
                <div class="col-md-8 ">
                    <div class="card">
                        <div class="card-header text-center">
                            Upload A Farm on Farmaax
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('farms.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="farm_category">Farm Category</label>
                                    <select class="form-control" name="farm_category" id="farm_category" required>
                                        <option selected disabled>Select farm Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="farm_type">Farm Type</label>
                                    <select class="form-control" name="farm_type" id="farm_type" required>
                                        <option selected disabled>Select farm type</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Country <span class="text-danger"><strong>*</strong></span></label>
                                    <select class='form-control pick-country' name="country" id="pick-country">
                                        <option class="myChooseCountry" selected disabled>Choose country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e(ucfirst($country->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>State <span class="text-danger"><strong>*</strong></span></label>
                                    <select class='form-control pick-state' name="state" id="pick-state">
                                        <option class="myState" value="" selected disabled>State</option>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>LGA <span class="text-danger"><strong>*</strong></span></label>
                                    <select class='form-control pick-lga' name="lga" id="pick-lga">
                                        <option class="myTown" value="" selected disabled>LGA</option>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Location <span class="text-danger"><strong>*</strong></span></label>
                                    <select class='form-control pick-town' name="town" id="pick-town">
                                        <option class="myTown" value="" selected disabled>Select your Location</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="description">Farm Description: </label>
                                    <textarea class="form-control" name="description" id="description" rows="6"
                                        required></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="duration">Duration (months):</label>
                                    <input type="number" name="duration" id="duration" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="duration">Unit Cost (Naira):</label>
                                    <input type="number" name="unit_cost" id="unit_cost" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="duration">overall Cost (Naira):</label>
                                    <input type="number" name="overall_cost" id="overall_cost" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="duration">Profit (%):</label>
                                    <input type="number" name="profit" id="profit" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="turn_over_date">No. of units:</label>
                                    <input type="number" name="units" id="units" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="turn_over_date">Turn Over Date:</label>
                                    <input type="date" name="turn_over_date" id="turn_over_date" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="hand_over_date">Hand Over Date:</label>
                                    <input type="date" name="hand_over_date" id="hand_over_date" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="coverImage">Farm Cover Image:</label>
                                    <input type="file" class="form-control" name="coverImage" id="coverImage"
                                        placeholder="Farm Cover Image">
                                    <?php $__errorArgs = ['coverImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <li class="text-danger"><?php echo e($message); ?></li>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="farmImages">Farm Images:</label>
                                    <input type="file" multiple class="form-control" name="farmImages[]" id="farmImages">
                                    <?php $__errorArgs = ['farmImages[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <li class="text-danger"><?php echo e($message); ?></li>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <button type="submit" class=" btn-block btn btn-primary">Upload Farm</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <script>
            $('.pick-country').on('change', function() {
                let country_id = $(this).val();

                $.ajax('pickstates', {
                    type: 'POST',
                    data: {
                        'country_id': country_id,
                        '_token': universal_token,
                    }, // data to submit
                    success: function(feedback, status, xhr) {



                        let arr_count = -1
                        let result = JSON.parse(feedback);

                        $('.pick-state').empty();
                        var listItem = "";
                        $('.pick-state').append(
                            `<option class="myState" selected disabled>State</option>`);
                        $.each(result, function() {
                            arr_count++;
                            listItem += "<option value=" + result[arr_count]['id'] + ">" +
                                result[arr_count]['name'] + "</option>";

                            // let name=;
                            // let id=result[arr_count]['id'];
                            // $('.pick-state').append(`<option class="myState" value="`+id+`">`+name+`</option>`);
                        })
                        $('.pick-state').append(listItem);
                    },
                    error: function(jqXhr, textStatus, errorMessage) {
                        console.log(errorMessage);

                    }
                });
                /*$.post('pickstates', {
                'country_id':country_id,

                },
                function(feedback){
                console.log(feedback);

                var arr_count=-1
                result=JSON.parse(feedback);

                $('.pick-lga').empty();

                $('.pick-lga').append(`<option selected disabled>Select your LGA</option>`);
                $.each(result, function(){
                arr_count++;
                let name=result[arr_count]['name'];
                let id=result[arr_count]['id'];
                $('.pick-lga').append(`<option value="`+id+`">`+name+`</option>`);
                })

                })*/
            })
            // Loading LGA from database when state is selected

            $('.pick-state').on('change', function() {
                let state_id = $(this).val();
                $.post('picklgas', {
                        'state_id': state_id,
                        '_token': universal_token,
                    },
                    function(feedback) {

                        let arr_count = -1
                        let result = JSON.parse(feedback);

                        $('.pick-lga').empty();

                        $('.pick-lga').append(`<option selected disabled>Select your LGA</option>`);
                        $.each(result, function() {
                            arr_count++;
                            let name = result[arr_count]['name'];
                            let id = result[arr_count]['id'];
                            $('.pick-lga').append(`<option value="` + id + `">` + name + `</option>`);
                        })

                    })
            })

            // loading towns from database when LGA is selected

            $('.pick-lga').on('change', function() {
                let lga_id = $(this).val();
                $.post('picktowns', {
                        'lga_id': lga_id,
                        '_token': universal_token,
                    },
                    function(feedback) {
                        let arr_count = -1
                        let result = JSON.parse(feedback);
                        $('.pick-town').empty();

                        $('.pick-town').append(`<option selected disabled>Select your location </option>`);
                        $.each(result, function() {
                            arr_count++;
                            let name = result[arr_count]['name'];
                            let id = result[arr_count]['id'];
                            $('.pick-town').append(`<option value="` + id + `">` + name + `</option>`);
                        })

                    })
            })

        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\farmaax2\resources\views/farms/create.blade.php ENDPATH**/ ?>