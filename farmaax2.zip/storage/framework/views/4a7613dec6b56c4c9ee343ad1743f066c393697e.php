<?php if( session('msg')): ?>
  <?php
    $mymessage=session('msg');
    $myalert=session('alert');
  ?>
  <div class="alert alert-<?php echo e($myalert); ?> alert-dismissible fade show mt-3" role="alert">
    <strong>Alert!</strong> <?php echo e($mymessage); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php
    session()->forget('msg');
    ?>
<?php endif; ?>  <?php /**PATH C:\wamp64\www\farmaax2\resources\views/layouts/alert.blade.php ENDPATH**/ ?>