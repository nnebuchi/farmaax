<?php $__env->startSection('title', 'My Lands'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row my-5">
            <div class="col-md-6 offset-md-3 item">
                <h2 class="text-center">List of my Lands</h2>

            </div>
        </div>
        <?php if(count($lands) > 0): ?>

            <div class="row my-5">
                <?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 ">
                        <a href="<?php echo e(route('lands.show', $land->id)); ?>">
                            <div class="card">
                                <div class="card-img-top">
                                    <img src="<?php echo e(asset('/storage/landForSaleCoverImages/' . $land->coverImage)); ?>"
                                        alt="land image" width="100%" height="200px">
                                </div>
                                <div class="card-footer">
                                    <h4 class=""> <?php echo e($land->landTitle); ?> - &#8358;<?php echo e(number_format($land->price)); ?></h4>
                                    <br>
                                    <p class=""><a class=" btn btn-success"
                                            href="<?php echo e(route('lands.show', $land->id)); ?> ">View</a></p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="jumbotron text-center">
                <h3>No Land Available </h3>
                <a href="<?php echo e(route('lands.index')); ?>" class="btn btn-primary">Buy A Land</a>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\farmaax2\resources\views/users/my-lands.blade.php ENDPATH**/ ?>