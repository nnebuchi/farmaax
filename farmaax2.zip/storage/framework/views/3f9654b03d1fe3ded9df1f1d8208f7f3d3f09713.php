    
    <?php $__env->startSection('title', 'Add farm category'); ?>
    <?php $__env->startSection('content'); ?>
    <style>
    input{
        border: 2px solid #676501!important;
    }

    label{
        color: #4e9525 !important;
    }

    .card{
        border: 2px solid #676501 !important; border-radius: 12px;">
    }

    .card-header{
        border-radius: 12px; background-color: #4e9525 !important; border-bottom: 2px solid  #676501; color: white;
        font-weight: bold;
    }

    .card-header h4{
        color: white;
        font-weight: bold;
    }

    
</style>
        <div class="container mt-4">
            <div class="row justify-content-center">
                <div class="col-md-8 ">
                    <div class="card">
                        <div class="card-header text-center">
                            Add farm type
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(url('dashboard/admin/storefarmtype')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="farm_type">Category</label>
                                    <select name="parent" class="form-control" id="parent">
                                        <option disabled selected>select catgory</option>

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <li class="text-danger"><?php echo e($message); ?></li>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="farm_type">Farm type</label>
                                    <input type="text" name="name" class="form-control" id="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <li class="text-danger"><?php echo e($message); ?></li>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                 
                                
                                <div class="form-group">
                                    <label for="image">type Image:</label>
                                    <input type="file" class="form-control imgInp" name="image" id="image"
                                        placeholder="type Image" required>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <li class="text-danger"><?php echo e($message); ?></li>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <img id="blah" class="mt-2 mb-3" src="<?php echo e(asset('images/thumbnail.jpg')); ?>" alt="your image" height="200" />
                                
                                <button type="submit" class=" btn-block btn btn-success">Submit</button>
                            </form>
                        </div>



                    </div>
                </div>

                <div class="col-md-8 offset-md-2 mt-3"> 

                    <h3>Existing Farm types</h3>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Icon</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $farmtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                       
                            <tr>
                                <td><?php echo e($type->name); ?></td>
                                <td><img src="<?php echo e(asset('storage/farmcategoryImages/'.$type->image)); ?>" height="50" width="50" class="rounded-circle"></td>
                                <td><a href="<?php echo e(url('dashboard/admin/editfarmtype/'.$type->id)); ?>" class="btn btn-sm btn-success">Edit <i class="fa fa-edit"></i></a> <a href="<?php echo e(route('costAnalysis', $type->id)); ?>" class="btn btn-sm btn-warning">Add Farm Cost Analysis <i class="fa fa-edit"></i></a></td>
                             
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                     
                </div>

            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\farmaax2\resources\views/farms/addfarmtype.blade.php ENDPATH**/ ?>