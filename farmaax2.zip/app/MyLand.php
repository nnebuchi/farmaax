<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MyLand extends Model
{
    //
    protected $guarded = [];
}
