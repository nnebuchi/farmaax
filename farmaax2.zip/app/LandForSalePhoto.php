<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LandForSalePhoto extends Model
{
    //
    protected $guarded = [];
}
